import React, { useState, useEffect, useRef } from 'react'
import {
  Square,
  Send,
  RotateCcw,
  CheckCircle2,
  FileEdit,
  Radio,
  SlidersHorizontal,
  Info,
  Lock,
  ArrowRight
} from 'lucide-react'

// Canonical phrase from the prototype
const PHRASE = [
  'Follow-up',
  'email',
  'to',
  'the',
  'hiring',
  'manager.',
  'Still',
  'interested,',
  'and',
  'our',
  'chat',
  'about',
  'the',
  'marketing',
  'roll.'
]

interface Message {
  id: string
  role: 'assistant' | 'user'
  text: string
  isTyping?: boolean
}

export default function App() {
  // Steps: 1: Mic, 2: Listen, 3: Draft, 4: Fix, 5: Send
  const [currentStep, setCurrentStep] = useState<number>(1)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      role: 'assistant',
      text: 'Hi! What can I help you with today?'
    }
  ])

  // Recording & Drafting state
  const [recording, setRecording] = useState<boolean>(false)
  const [heardWords, setHeardWords] = useState<string[]>([])
  const [seconds, setSeconds] = useState<number>(0)
  const [draftState, setDraftState] = useState<'none' | 'drafting'>('none')
  const [showAlts, setShowAlts] = useState<boolean>(false)
  const [showStructChip, setShowStructChip] = useState<boolean>(false)
  const [decision, setDecision] = useState<'none' | 'role' | 'roll'>('none')
  const [hintText, setHintText] = useState<string>('Tap the underlined word. Nothing has been sent.')
  const [calloutTitle, setCalloutTitle] = useState<string>('What this does.')
  const [calloutBody, setCalloutBody] = useState<string>(
    'The mic still starts a recording. The words land in a draft first, and you can fix the unsure word before ChatGPT sees them.'
  )
  const [audioLevel, setAudioLevel] = useState<number[]>([8, 14, 22, 16, 26, 32, 20, 24, 14, 10])

  // Refs
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const wordTimerRef = useRef<NodeJS.Timeout | null>(null)
  const chatScrollRef = useRef<HTMLDivElement>(null)
  const draftBoxRef = useRef<HTMLDivElement>(null)

  // Auto-scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight
    }
  }, [messages, recording, draftState])

  // Clean timers
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (wordTimerRef.current) clearInterval(wordTimerRef.current)
    }
  }, [])

  // Audio equalizer oscillation only while actively recording
  useEffect(() => {
    if (!recording) return
    const interval = setInterval(() => {
      setAudioLevel(
        Array.from({ length: 10 }, () => Math.floor(Math.random() * 24) + 6)
      )
    }, 120)
    return () => clearInterval(interval)
  }, [recording])

  // Format seconds to mm:ss cleanly
  const formatTimer = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60)
    const s = String(totalSeconds % 60).padStart(2, '0')
    return `${m}:${s}`
  }

  const showIdle = () => {
    setRecording(false)
    if (timerRef.current) clearInterval(timerRef.current)
    if (wordTimerRef.current) clearInterval(wordTimerRef.current)
    setDraftState('none')
    setShowAlts(false)
    setShowStructChip(false)
    setHeardWords([])
    setSeconds(0)
    setDecision('none')
    setCurrentStep(1)
  }

  const startRecording = () => {
    if (recording) return
    setRecording(true)
    setDraftState('none')
    setShowAlts(false)
    setShowStructChip(false)
    setDecision('none')
    setHeardWords([])
    setSeconds(0)
    setCurrentStep(2)
    setCalloutTitle('Listening.')
    setCalloutBody(
      'The chat above stays as it is. Stop when the line finishes, or stop early.'
    )

    // Accurate clock timer
    timerRef.current = setInterval(() => {
      setSeconds((prev) => prev + 1)
    }, 1000)

    // Stream phrase words
    let index = 0
    const accumulated: string[] = []
    wordTimerRef.current = setInterval(() => {
      if (index < PHRASE.length) {
        accumulated.push(PHRASE[index])
        setHeardWords([...accumulated])
        index += 1
        if (index >= PHRASE.length) {
          finishRecording(true, accumulated)
        }
      }
    }, 320)
  }

  const cancelRecording = () => {
    showIdle()
    setCalloutTitle('Cancelled.')
    setCalloutBody('Nothing was written, and nothing was sent.')
  }

  const finishRecording = (completed: boolean, finalWords?: string[]) => {
    setRecording(false)
    if (timerRef.current) clearInterval(timerRef.current)
    if (wordTimerRef.current) clearInterval(wordTimerRef.current)

    const wordsToUse = finalWords || heardWords
    if (!wordsToUse.length) {
      showIdle()
      return
    }

    const text = wordsToUse.join(' ')
    openDraft(text, completed)
  }

  const openDraft = (text: string, completed: boolean) => {
    setDraftState('drafting')
    setShowAlts(false)
    setShowStructChip(false)
    setCurrentStep(3)

    const risky = /\broll\b/i.test(text)
    if (risky) {
      setHintText('Tap the underlined word. Nothing has been sent.')
      setCalloutTitle('This is a draft, not a message.')
      setCalloutBody(
        '“Roll” is marked because it might be the wrong word. The chat has not changed.'
      )
    } else {
      setHintText('You stopped early. Check this, then send it or throw it away.')
      setCalloutTitle('This is a draft, not a message.')
      setCalloutBody(
        'Only the words heard so far are here. Sending is still its own step.'
      )
    }

    // Populate editable container with clickable word
    setTimeout(() => {
      if (draftBoxRef.current) {
        if (risky) {
          draftBoxRef.current.innerHTML = text.replace(
            /\broll\b/i,
            `<span class="fixword underline decoration-wavy decoration-[#c0392b] underline-offset-4 text-[#1c1a17] font-semibold cursor-pointer px-1 py-0.5 rounded hover:bg-amber-100 transition-colors" id="fixword">roll</span>`
          )
          const wordEl = draftBoxRef.current.querySelector('#fixword')
          if (wordEl) {
            wordEl.addEventListener('click', (e) => {
              e.stopPropagation()
              setShowAlts(true)
              setCurrentStep(4)
            })
          }
        } else {
          draftBoxRef.current.innerText = text
          if (completed && text.split(/\s+/).length > 8) {
            setShowStructChip(true)
          }
        }
      }
    }, 0)
  }

  const handleSelectAlternative = (choice: 'role' | 'roll') => {
    setDecision(choice)
    setShowAlts(false)
    setCurrentStep(4)

    if (draftBoxRef.current) {
      const word = draftBoxRef.current.querySelector('#fixword')
      if (word) {
        if (choice === 'role') {
          const span = document.createElement('span')
          span.className = 'fixed-word bg-[#e7f3ea] text-[#1c1a17] rounded px-1.5 py-0.5 font-medium border border-[#b8dfc4]'
          span.textContent = 'role'
          word.replaceWith(span)
          setHintText('Changed to “role”. Still not sent.')
          setCalloutTitle('Fixed before you send.')
          setCalloutBody(
            'ChatGPT will see “role”, not “roll”. Tap Send when the draft looks right.'
          )
        } else {
          const textNode = document.createTextNode('roll')
          word.replaceWith(textNode)
          setHintText('You kept “roll”. You can still change the draft, then send.')
          setCalloutTitle('You kept “roll”.')
          setCalloutBody(
            'If you send this, ChatGPT will write about a marketing roll. The draft is here so you can catch that.'
          )
        }
      }

      if (draftBoxRef.current.innerText.split(/\s+/).length > 8) {
        setShowStructChip(true)
      }
    }
  }

  const handleApplyStructure = () => {
    if (!draftBoxRef.current) return
    const spoken = draftBoxRef.current.innerText
    const topic = /\brole\b/i.test(spoken) ? 'role' : (/\broll\b/i.test(spoken) ? 'roll' : 'topic')
    draftBoxRef.current.innerHTML =
      '<b>Follow-up email</b><br>' +
      '• Thank the hiring manager<br>' +
      '• Say you are still interested<br>' +
      '• Mention the marketing ' + topic + '<br>' +
      '• Close warmly'
    setShowStructChip(false)
    setShowAlts(false)
    setHintText('Still a draft. Send when you want this version.')
    setCalloutTitle('Later idea. Still not sent.')
    setCalloutBody(
      'Only the draft turned into a clean list. The chat stays the same until you tap Send.'
    )
  }

  const handleDiscard = () => {
    showIdle()
    setCalloutTitle('Discarded.')
    setCalloutBody('The draft is gone. The chat never received it.')
  }

  // Exact verbatim prompt replies from original prototype
  const replyFor = (text: string) => {
    const role = /\brole\b/i.test(text)
    const roll = /\broll\b/i.test(text)
    if (roll && !role) {
      return 'I wrote this about a marketing roll. If you meant the job, the marketing role, say so and I’ll rewrite it.'
    }
    if (role) {
      return 'Here’s a follow-up for the marketing role. It thanks them, says you’re still interested, and mentions your chat. Want a warmer ending?'
    }
    return 'Here’s a first try from what you sent. Want me to change the tone?'
  }

  const handleSend = () => {
    if (!draftBoxRef.current) return
    const text = draftBoxRef.current.innerText.replace(/\s+/g, ' ').trim()
    if (!text) return

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: draftBoxRef.current.innerText
    }

    setMessages((prev) => [...prev, userMsg])
    setDraftState('none')
    setShowStructChip(false)
    setShowAlts(false)
    setCurrentStep(5)

    // Assistant typing state
    const typingMsgId = `typing-${Date.now()}`
    setMessages((prev) => [
      ...prev,
      {
        id: typingMsgId,
        role: 'assistant',
        text: '',
        isTyping: true
      }
    ])

    const answer = replyFor(text)
    setTimeout(() => {
      setMessages((prev) =>
        prev
          .filter((m) => m.id !== typingMsgId)
          .concat({
            id: `assistant-${Date.now()}`,
            role: 'assistant',
            text: answer
          })
      )
    }, 900)

    const fixed = /\brole\b/i.test(text) && !/\broll\b/i.test(text)
    setCalloutTitle(fixed ? 'Sent after you checked it.' : 'Sent as heard.')
    setCalloutBody(
      fixed
        ? 'The chat now has the edited draft, and the reply is about the role.'
        : 'The reply follows the words you sent. If you had changed “roll” to “role” first, that’s what would have gone out.'
    )
  }

  const handleRestart = () => {
    setMessages([
      {
        id: 'init-1',
        role: 'assistant',
        text: 'Hi! What can I help you with today?'
      }
    ])
    showIdle()
    setCalloutTitle('What this does.')
    setCalloutBody(
      'The mic still starts a recording. The words land in a draft first, and you can fix the unsure word before ChatGPT sees them.'
    )
  }

  return (
    <div className="min-h-screen bg-[#0d0e12] text-zinc-100 flex flex-col justify-between selection:bg-amber-500/30 selection:text-amber-200 font-sans">
      {/* Background subtle mesh grid */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-1/2 -translate-x-1/2 w-[680px] h-[360px] bg-gradient-to-b from-amber-600/10 via-amber-900/5 to-transparent blur-3xl opacity-60" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff04_1px,transparent_1px),linear-gradient(to_bottom,#ffffff04_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_35%,#000_70%,transparent_100%)]" />
      </div>

      {/* Top Header */}
      <header className="relative z-10 w-full border-b border-white/[0.08] bg-[#111318]/90 backdrop-blur-md px-6 py-4">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-[#edf0e6] text-[#5b6b4f] text-[11px] font-bold tracking-wide uppercase mb-1 border border-[#5b6b4f]/30">
              AI-ASSISTED PROTOTYPE · VOICE DRAFT MODE
            </div>
            <h1 className="text-lg font-bold tracking-tight text-white">
              Voice stays a draft until you send it
            </h1>
            <p className="text-xs text-zinc-400 mt-0.5">
              Tap the mic. You’ll hear a sample line with one wrong word. Fix it, then send.
            </p>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-xs text-zinc-300">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>The chat stays the same until you tap Send</span>
          </div>
        </div>
      </header>

      {/* Main Interactive Container */}
      <main className="relative z-10 max-w-5xl mx-auto w-full px-4 py-6 flex-1 flex flex-col items-center">
        {/* Step Progress Bar */}
        <div className="w-full max-w-md mb-6">
          <div className="grid grid-cols-5 gap-2 text-center text-xs">
            {[
              { num: 1, label: 'Mic' },
              { num: 2, label: 'Listen' },
              { num: 3, label: 'Draft' },
              { num: 4, label: 'Fix' },
              { num: 5, label: 'Send' }
            ].map((step) => {
              const active = currentStep === step.num
              const done = currentStep > step.num
              return (
                <div
                  key={step.num}
                  className={`group relative flex flex-col items-center pt-2 transition-colors duration-200 ${
                    active
                      ? 'text-amber-300 font-bold'
                      : done
                      ? 'text-emerald-400 font-semibold'
                      : 'text-zinc-500'
                  }`}
                >
                  <div
                    className={`h-0.5 w-full absolute top-0 rounded-full transition-all duration-200 ${
                      active
                        ? 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                        : done
                        ? 'bg-emerald-500'
                        : 'bg-zinc-800'
                    }`}
                  />
                  <span className="font-mono text-[11px]">
                    {step.num} · {step.label}
                  </span>
                </div>
              )
            })}
          </div>
        </div>

        {/* 3-Column Layout: Overview, Phone Mockup, Details & Callout */}
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start justify-center max-w-5xl">
          {/* Left Column: Simple Story Explanation */}
          <div className="lg:col-span-4 hidden lg:flex flex-col gap-4">
            <div className="p-5 rounded-2xl bg-zinc-900/70 border border-white/[0.08] backdrop-blur-sm shadow-md">
              <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-bold block mb-2">
                How this works
              </span>
              <h3 className="text-sm font-bold text-white mb-2">
                Check the words before they go to ChatGPT
              </h3>
              <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                Right now, voice sends whatever the phone heard. If it hears the wrong word, ChatGPT answers the wrong thing.
              </p>
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-zinc-300">
                  <div className="font-semibold text-rose-400 mb-0.5">Today’s voice</div>
                  <div>You let go of the mic and it sends right away. A wrong word gets a wrong answer.</div>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 border border-amber-500/20 text-zinc-300">
                  <div className="font-semibold text-amber-300 mb-0.5">Voice Draft Mode</div>
                  <div>You let go of the mic, the words sit in a draft, you fix any word, then you send.</div>
                </div>
              </div>
            </div>

            {/* Step Walkthrough */}
            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/[0.08] shadow-sm">
              <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-400 font-bold block mb-3">
                Try it
              </span>
              <ul className="text-xs space-y-2.5 text-zinc-300">
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">
                    1
                  </span>
                  <span>Tap the mic and start talking.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">
                    2
                  </span>
                  <span>The words show up as the phone hears them.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">
                    3
                  </span>
                  <span>Tap <strong className="text-amber-300">“roll”</strong> to change it to <strong className="text-emerald-300">“role”</strong>. You can also tap the box and change any word.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">
                    4
                  </span>
                  <span>Tap <strong className="text-white">Send</strong> when the draft looks right.</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Center Column: Phone Mockup */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-[375px] max-w-[94vw] h-[720px] bg-[#ffffff] rounded-[38px] shadow-[0_20px_50px_rgba(0,0,0,0.6)] flex flex-col overflow-hidden border-[8px] border-[#1c1b20] relative text-[#1c1a17]">
              {/* Status Bar */}
              <div className="h-8 px-6 pt-1 flex items-center justify-between text-[11px] font-semibold text-[#1c1a17] select-none shrink-0 z-20">
                <span>9:41</span>
                <span>●●●● 5G 100%</span>
              </div>

              {/* Chat Topbar */}
              <div className="px-4 py-2.5 border-b border-[#e5e1d8] flex items-center justify-between bg-white shrink-0">
                <h2 className="text-base font-bold text-[#1c1a17] tracking-tight">
                  ChatGPT
                </h2>
                <button
                  onClick={handleRestart}
                  title="Restart demo"
                  className="p-1 rounded-full text-[#837d72] hover:text-[#1c1a17] hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Chat Thread */}
              <div
                ref={chatScrollRef}
                className="flex-1 overflow-y-auto px-3.5 py-3 space-y-2.5 scroll-smooth bg-[#f8f7f4]"
              >
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[82%] px-3.5 py-2.5 rounded-2xl text-[13.5px] leading-relaxed shadow-xs ${
                        msg.role === 'user'
                          ? 'bg-[#7a2e3a] text-white rounded-br-xs'
                          : 'bg-[#efebe4] text-[#1c1a17] rounded-bl-xs'
                      }`}
                    >
                      {msg.isTyping ? (
                        <div className="flex items-center gap-1.5 py-1 px-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#837d72] animate-bounce" />
                          <span className="w-1.5 h-1.5 rounded-full bg-[#837d72] animate-bounce [animation-delay:0.2s]" />
                          <span className="w-1.5 h-1.5 rounded-full bg-[#837d72] animate-bounce [animation-delay:0.4s]" />
                        </div>
                      ) : (
                        <div className="whitespace-pre-line font-sans">{msg.text}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Input Zone */}
              <div className="shrink-0 border-t border-[#e5e1d8] bg-white p-3 relative transition-all duration-200">
                {/* 1. IDLE ROW */}
                {!recording && draftState === 'none' && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-[#f2f1f4] rounded-full px-4 py-2.5 text-[13.5px] text-[#837d72]">
                        Message ChatGPT
                      </div>

                      <button
                        id="micBtn"
                        onClick={startRecording}
                        className="w-10 h-10 rounded-full bg-[#7a2e3a] hover:bg-[#8e3544] active:scale-95 text-white flex items-center justify-center transition-transform cursor-pointer shadow-sm"
                        title="Tap to speak"
                      >
                        {/* Crisp, clean standard microphone SVG */}
                        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                          <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z" />
                          <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
                        </svg>
                      </button>
                    </div>

                    <div className="text-[11px] text-[#837d72] text-center pt-0.5">
                      Nothing sends until you tap Send.
                    </div>
                  </div>
                )}

                {/* 2. RECORDING ROW */}
                {recording && (
                  <div className="space-y-2 py-0.5">
                    <div className="flex items-center justify-between gap-2.5 bg-[#f9f7f4] border border-[#e5e1d8] rounded-full px-3 py-1.5">
                      {/* Cancel */}
                      <button
                        onClick={cancelRecording}
                        title="Cancel"
                        className="w-7 h-7 rounded-full bg-[#efebe4] hover:bg-zinc-200 text-[#1c1a17] flex items-center justify-center transition-colors cursor-pointer text-base font-bold"
                      >
                        ×
                      </button>

                      {/* Equalizer Wave */}
                      <div className="flex-1 flex items-center justify-center gap-1 h-6 px-1">
                        {audioLevel.map((lvl, idx) => (
                          <span
                            key={idx}
                            style={{ height: `${lvl}px` }}
                            className="w-1 bg-[#c0392b] rounded-full transition-all duration-100 ease-out"
                          />
                        ))}
                      </div>

                      {/* Timer */}
                      <div className="font-mono text-xs font-bold text-[#c0392b] min-w-9 text-right">
                        {formatTimer(seconds)}
                      </div>

                      {/* Stop and review */}
                      <button
                        onClick={() => finishRecording(false)}
                        title="Stop and review"
                        className="w-8 h-8 rounded-full bg-[#c0392b] hover:bg-[#a93226] active:scale-95 text-white flex items-center justify-center cursor-pointer shadow-sm"
                      >
                        <Square className="w-3 h-3 fill-current" />
                      </button>
                    </div>

                    {/* Live streaming line */}
                    <div className="text-xs text-[#1c1a17] px-1 truncate">
                      {heardWords.length ? (
                        <span>{heardWords.join(' ')}</span>
                      ) : (
                        <em className="text-[#837d72]">Listening… nothing is sent from here.</em>
                      )}
                    </div>
                  </div>
                )}

                {/* 3. DRAFT REVIEW WRAP */}
                {draftState === 'drafting' && (
                  <div className="space-y-2.5">
                    {/* Header */}
                    <div className="flex items-center gap-1.5 text-[10.5px] font-bold tracking-wide text-[#d98e04]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#d98e04] animate-pulse" />
                      <span>Draft. Not sent yet.</span>
                    </div>

                    {/* Contenteditable Draft Box */}
                    <div
                      ref={draftBoxRef}
                      contentEditable
                      suppressContentEditableWarning
                      className="w-full min-h-[50px] max-h-36 overflow-y-auto p-3 rounded-2xl bg-[#fff8ea] text-[#1c1a17] border-[1.5px] border-dashed border-[#d98e04] focus:outline-none focus:bg-[#fffdf5] text-[13.5px] leading-relaxed font-sans shadow-xs"
                    />

                    {/* Alternatives Selector */}
                    {showAlts && (
                      <div className="flex items-center gap-2 flex-wrap text-xs pt-0.5">
                        <span className="text-[#837d72] text-[11px]">Heard “roll”.</span>
                        <button
                          type="button"
                          onClick={() => handleSelectAlternative('role')}
                          className="border border-[#7a2e3a] text-[#7a2e3a] bg-[#7a2e3a]/10 hover:bg-[#7a2e3a]/20 rounded-full px-3 py-1 text-xs font-bold cursor-pointer"
                        >
                          role
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectAlternative('roll')}
                          className="border border-[#e5e1d8] text-[#1c1a17] bg-white hover:bg-zinc-100 rounded-full px-3 py-1 text-xs font-bold cursor-pointer shadow-xs"
                        >
                          keep roll
                        </button>
                      </div>
                    )}

                    {/* Phase 2: Structured List Chip */}
                    {showStructChip && (
                      <button
                        type="button"
                        onClick={handleApplyStructure}
                        className="flex items-center gap-2 bg-[#edf0e6] text-[#5b6b4f] border border-[#5b6b4f] rounded-full px-3 py-1.5 text-[11.5px] font-bold cursor-pointer hover:bg-[#e4e9db] transition-colors"
                      >
                        <span className="text-[8.5px] bg-[#5b6b4f] text-white rounded px-1.5 py-0.5 font-extrabold uppercase">
                          LATER
                        </span>
                        <span>Turn this into a clean list?</span>
                      </button>
                    )}

                    {/* Hint */}
                    <div className="text-[11px] text-[#837d72]">
                      {hintText}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-1">
                      <button
                        type="button"
                        onClick={handleDiscard}
                        className="text-xs text-[#837d72] hover:text-[#1c1a17] font-semibold cursor-pointer py-1.5 px-1"
                      >
                        Discard
                      </button>
                      <button
                        type="button"
                        onClick={handleSend}
                        className="bg-[#7a2e3a] hover:bg-[#8e3544] active:scale-96 text-white rounded-full px-4 py-2 text-xs font-bold cursor-pointer shadow-sm flex items-center gap-1.5"
                      >
                        <span>Send</span>
                        <Send className="w-3 h-3 fill-current" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: State Inspector & Callout Box */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            {/* Clear, Grounded State Inspector */}
            <div className="p-5 rounded-2xl bg-zinc-900/70 border border-white/[0.08] backdrop-blur-sm shadow-md">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Live Status
                </span>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-zinc-400 text-[11px] block mb-1">Current Step</span>
                  <div className="font-mono text-white bg-black/40 px-2.5 py-1.5 rounded-lg border border-white/5 flex items-center justify-between">
                    <span>
                      {recording
                        ? 'Listening'
                        : draftState === 'drafting'
                        ? 'Checking the draft'
                        : 'Ready'}
                    </span>
                    <span className="text-amber-400 text-[11px]">Step {currentStep} of 5</span>
                  </div>
                </div>

                <div>
                  <span className="text-zinc-400 text-[11px] block mb-1">Chat</span>
                  <div className="font-mono text-zinc-300 bg-black/40 px-2.5 py-1.5 rounded-lg border border-white/5">
                    {currentStep === 5 ? 'Message is in the chat' : 'Nothing sent yet'}
                  </div>
                </div>

                <div>
                  <span className="text-zinc-400 text-[11px] block mb-1">Word Check</span>
                  <div className="mt-1">
                    {currentStep < 3 ? (
                      <div className="text-zinc-500 text-xs bg-black/40 px-2.5 py-1.5 rounded-lg border border-white/5">
                        Waiting for you to talk
                      </div>
                    ) : (
                      <div className="bg-black/40 p-2.5 rounded-lg border border-white/5 space-y-1.5">
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-zinc-300">Word:</span>
                          <span
                            className={
                              decision === 'role'
                                ? 'text-emerald-400 font-bold'
                                : decision === 'roll'
                                ? 'text-zinc-400 font-bold'
                                : 'text-amber-400 font-bold'
                            }
                          >
                            {decision === 'role'
                              ? 'Fixed to “role”'
                              : decision === 'roll'
                              ? 'Kept “roll”'
                              : '“roll”. Check this.'}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Dynamic Step Callout Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-[#181a22] to-[#12131a] border border-amber-500/20 shadow-md">
              <div className="text-xs font-bold text-amber-300 mb-1.5">
                {calloutTitle}
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed font-sans">{calloutBody}</p>

              {/* Single, clean restart button with exactly one icon */}
              <button
                onClick={handleRestart}
                className="mt-4 w-full py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-white/10 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restart demo</span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full border-t border-white/[0.06] bg-[#0c0e12]/60 px-6 py-4 text-center text-xs text-zinc-400">
        <p>Voice Draft Mode. What you say stays in a draft until you send it.</p>
      </footer>
    </div>
  )
}
